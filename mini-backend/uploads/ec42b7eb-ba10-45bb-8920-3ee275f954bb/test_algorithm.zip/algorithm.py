
import numpy as np

def compress_ecg(signal):
    return signal[::2]  # Simple compression

def decompress_ecg(compressed):
    return np.repeat(compressed, 2)  # Simple decompression
