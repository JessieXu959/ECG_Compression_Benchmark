#!/usr/bin/env python3
"""
Simple ECG Compression Algorithm - Test Submission
"""

import numpy as np

def compress_ecg(signal):
    """
    Simple compression: downsample by factor of 2
    In practice, you would implement more sophisticated compression
    """
    if len(signal) % 2 != 0:
        signal = signal[:-1]  # Make even length

    compressed = signal[::2]  # Take every other sample
    return compressed

def decompress_ecg(compressed_signal):
    """
    Simple decompression: upsample by repeating samples
    In practice, you would implement interpolation or reconstruction
    """
    decompressed = np.repeat(compressed_signal, 2)
    return decompressed

def evaluate_compression(original, compressed):
    """
    Calculate compression metrics
    """
    # Decompress
    reconstructed = decompress_ecg(compressed)

    # Ensure same length
    min_len = min(len(original), len(reconstructed))
    original = original[:min_len]
    reconstructed = reconstructed[:min_len]

    # Calculate metrics
    mse = np.mean((original - reconstructed) ** 2)
    prd = np.sqrt(mse) / np.std(original) * 100  # PRD in percentage
    cr = len(original) / len(compressed)  # Compression ratio

    return {
        'CR': cr,
        'PRD': prd,
        'MSE': mse
    }

# Example usage
if __name__ == "__main__":
    # Generate sample ECG signal
    t = np.linspace(0, 10, 1000)  # 10 seconds, 100 Hz
    ecg_signal = np.sin(2 * np.pi * 1.2 * t) + 0.3 * np.sin(2 * np.pi * 2.4 * t)
    ecg_signal += 0.1 * np.random.randn(len(t))  # Add noise

    # Test compression
    compressed = compress_ecg(ecg_signal)
    metrics = evaluate_compression(ecg_signal, compressed)

    print(f"Compression Ratio: {metrics['CR']:.2f}")
    print(f"PRD: {metrics['PRD']:.4f}%")
    print(f"MSE: {metrics['MSE']:.6f}")
