# Test ECG Compression Algorithm

## Overview
This is a simple test algorithm for ECG compression challenge.

## Algorithm Description
- **Method**: Simple downsampling compression
- **Compression**: Takes every other sample (2:1 compression)
- **Decompression**: Repeats each sample twice

## Files
- `algorithm.py`: Main algorithm implementation
- `requirements.txt`: Dependencies
- `README.md`: This file

## Usage
```python
from algorithm import compress_ecg, decompress_ecg

# Compress ECG signal
compressed = compress_ecg(ecg_signal)

# Decompress
reconstructed = decompress_ecg(compressed)
```

## Performance
- Compression Ratio: ~2.0
- Expected PRD: 5-15%
- Processing Speed: Very fast

## Author
Test Team - ECG Compression Challenge
