"""
示例: ecg_model.py

说明：
- 这里定义一个类 ECGCompressor，提供 compress_and_reconstruct 方法。
- 评测时，ingestion.py 会通过 "from ecg_model import ECGCompressor" 来调用此类。
- 你可以在这里使用任意算法完成对ECG信号的压缩与重建。
"""

# ecg_model.py
import numpy as np

class ECGCompressor:
    def __init__(self):
        self.compression_ratio = 10.0  # 目标压缩比

    def compress_and_reconstruct(self, ecg_signal):
        """
        压缩和重构ECG信号

        Args:
            ecg_signal: 输入ECG信号

        Returns:
            tuple: (重构信号, 压缩比)
        """
        # 确保输入是numpy数组
        if not isinstance(ecg_signal, np.ndarray):
            ecg_signal = np.array(ecg_signal)

        original_length = len(ecg_signal)

        # 计算降采样因子以达到目标压缩比
        downsample_factor = max(2, int(original_length / (original_length / self.compression_ratio)))

        # 压缩逻辑 (自适应降采样)
        compressed_indices = np.arange(0, original_length, downsample_factor)
        compressed_data = ecg_signal[compressed_indices]

        # 计算压缩比 (CR)
        compressed_length = len(compressed_data)
        if compressed_length == 0:
            raise ValueError("Compressed signal is empty")
        cr_val = original_length / compressed_length

        # 重建信号 (线性插值 - 比简单重复更好的质量)
        full_indices = np.arange(original_length)
        f_recon = np.interp(full_indices, compressed_indices, compressed_data)

        # 确保重构信号与原始信号长度一致
        if len(f_recon) != original_length:
            if len(f_recon) > original_length:
                f_recon = f_recon[:original_length]
            else:
                # 填充至原始长度
                f_recon = np.pad(f_recon, (0, original_length - len(f_recon)), mode='edge')

        return f_recon, cr_val