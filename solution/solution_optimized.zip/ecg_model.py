"""
示例: ecg_model.py

说明：
- 这里定义一个类 ECGCompressor，提供 compress_and_reconstruct 方法。
- 评测时，ingestion.py 会通过 "from ecg_model import ECGCompressor" 来调用此类。
- 你可以在这里使用任意算法完成对ECG信号的压缩与重建。
"""

# ecg_model.py
import numpy as np
from scipy import signal

class ECGCompressor:
    def __init__(self):
        self.compression_ratio = 10.0  # 目标压缩比
        self.threshold = 0.05  # 阈值百分比，用于保留重要特征

    def compress_and_reconstruct(self, ecg_signal):
        """
        压缩和重构ECG信号，使用自适应采样和滤波

        Args:
            ecg_signal: 输入ECG信号

        Returns:
            tuple: (重构信号, 压缩比)
        """
        # 确保输入是numpy数组
        if not isinstance(ecg_signal, np.ndarray):
            ecg_signal = np.array(ecg_signal)

        original_length = len(ecg_signal)

        # 1. 预处理 - 去噪
        # 使用简单的移动平均滤波器去除高频噪声
        window_size = 5
        smoothed_signal = np.convolve(ecg_signal, np.ones(window_size)/window_size, mode='same')

        # 2. 计算信号的一阶差分，标识信号变化显著的区域
        diff = np.abs(np.diff(smoothed_signal, prepend=smoothed_signal[0]))

        # 3. 自适应采样 - 在信号变化显著的区域采样更密集
        # 计算阈值 - 差分的百分位数
        threshold = np.percentile(diff, 100 - self.threshold * 100)

        # 创建重要性权重
        importance = np.zeros_like(ecg_signal)
        importance[diff > threshold] = 1.0  # 在信号变化显著处标记为重要

        # 根据重要性和目标压缩比计算采样点
        target_points = int(original_length / self.compression_ratio)

        # 确保至少保留10%的采样点
        min_points = max(int(original_length * 0.1), target_points)

        # 分配采样点 - 重要区域的采样密度更高
        important_indices = np.where(importance > 0)[0]
        if len(important_indices) > 0:
            # 在重要区域保留70%的采样点
            important_count = min(int(target_points * 0.7), len(important_indices))
            # 在非重要区域保留剩余的采样点
            regular_count = target_points - important_count

            # 从重要索引中随机选择
            if len(important_indices) > important_count:
                important_indices = np.sort(np.random.choice(important_indices, important_count, replace=False))

            # 计算常规采样间隔
            regular_step = max(1, original_length // regular_count)
            regular_indices = np.arange(0, original_length, regular_step)

            # 合并索引并排序
            compressed_indices = np.sort(np.unique(np.concatenate([important_indices, regular_indices])))
        else:
            # 如果没有重要区域，则均匀采样
            step = max(1, original_length // target_points)
            compressed_indices = np.arange(0, original_length, step)

        # 获取压缩数据
        compressed_data = ecg_signal[compressed_indices]

        # 计算压缩比 (CR)
        compressed_length = len(compressed_data)
        if compressed_length == 0:
            raise ValueError("压缩信号为空")
        cr_val = original_length / compressed_length

        # 重建信号 (三次样条插值 - 比线性插值更好的质量)
        if len(compressed_indices) > 3:  # 需要至少4个点进行三次样条插值
            from scipy.interpolate import CubicSpline
            cs = CubicSpline(compressed_indices, compressed_data)
            f_recon = cs(np.arange(original_length))
        else:
            # 退回到线性插值
            f_recon = np.interp(np.arange(original_length), compressed_indices, compressed_data)

        # 确保重构信号与原始信号长度一致
        if len(f_recon) != original_length:
            if len(f_recon) > original_length:
                f_recon = f_recon[:original_length]
            else:
                # 填充至原始长度
                f_recon = np.pad(f_recon, (0, original_length - len(f_recon)), mode='edge')

        return f_recon, cr_val