# Evaluation
The performance of each submission will be evaluated based on the following metrics:
- **Compression Ratio**: The ratio of the original signal size to the compressed signal size.
- **Mean Squared Error (MSE)**: The difference between the original signal and the reconstructed signal.