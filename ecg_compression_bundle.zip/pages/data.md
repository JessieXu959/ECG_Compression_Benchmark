# Data Description

The input data consists of ECG signals in `.mat` format. Each file contains a single ECG recording.

## File Structure
- `PhysioNet_MITBIH_rec117_5min.mat`: ECG recording from PhysioNet MIT-BIH database.