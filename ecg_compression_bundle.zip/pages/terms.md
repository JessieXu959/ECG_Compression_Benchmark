# Terms and Conditions

By participating in this benchmark, you agree to the following terms:
- Submissions must be original work.
- The organizers reserve the right to disqualify any submission that violates the rules.